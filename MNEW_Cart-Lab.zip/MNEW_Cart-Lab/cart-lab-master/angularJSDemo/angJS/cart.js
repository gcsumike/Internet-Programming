var app=angular.module("cartApp",[]);

app.controller('cartCtrl', function($scope){
    // Q1) add two more pizza objects 
    $scope.pizzas=[
        {name:'Pepperoni',price:9.99,img: "pepperoni.jpg"},
        {name:'Alfredo',price:10.99,img: "chickenAlf.jpg"},
        {name:'Works',price:12.99,img:"works.jpg"},
        {name:'Veg',price:13.99,img:"veg.jpg"},
        {name: 'Hawaii', price: 11.99, img:"hawaii.jpg" },
        {name: 'Cheese', price: 8.99, img: "cheese.jpg"}
    ]
    // add two variables: cart, and total for web page cart.html
 	$scope.cart = JSON.parse(localStorage.getItem("cart"))
    if($scope.cart == null) {
        $scope.cart = []
        $scope.total = 0
        $scope.numItems = 0
    }
    else {
        $scope.numItems = $scope.cart.reduce((total, item) => total + item.quantity,0)
        // update price in Q5
    }
  

//Q2: addToCart() function
    $scope.addToCart = function (item) {
        let index = $scope.cart.findIndex(x =>x.name == item.name)
        if(index == -1){
            item.quantity = 1;
            //item has four properties name price img and quantity
            $scope.cart.push(item);
        }
        else {
            $scope.cart[index].quantity += 1
        }

        $scope.numItems += 1;
        localStorage.setItem("cart", JSON.stringify($scope.cart))
        //store cart locally so every web page can access it

        //add to cart
        //update total items
        //update price
    }

//Q3: removeFromCart() function
$scope.removeFromCart = function (item) {
        let index = $scope.cart.findIndex(x =>x.name == item.name)
        //if not in cart do nothing
        if(index == -1){
            //nothing here
        }
        else {
            //if there is more than 1 of the item just remove 1
            if($scope.cart[index].quantity > 1){
                $scope.numItems -= 1;
                $scope.cart[index].quantity -= 1;

            }
            //else if there is only only of the item remove 1 and delete from cart
            else{
                $scope.numItems -= 1;
                $scope.cart[index].quantity -= 1;
                $scope.cart.splice(index, 1);
            }            

        }

       
        localStorage.setItem("cart", JSON.stringify($scope.cart))
        //store cart locally so every web page can access it
        $scope.calcTotalPrice();
    }


//Q4: clearCart() function
$scope.clearCart = function() {   
    $scope.cart = [];
    $scope.numItems = 0;
    $scope.total = 0;
    localStorage.clear();
} 

//Q5: calcTotalPrice() function
    $scope.calcTotalPrice = function(){
        $scope.total = 0;
        //for each item in the cart
        $scope.cart.forEach( function (item){
            $scope.total += item.price * item.quantity;
        });

    }   
	
});